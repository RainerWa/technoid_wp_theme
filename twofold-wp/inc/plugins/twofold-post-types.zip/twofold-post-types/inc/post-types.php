<?php
/* Albums */
function thb_post_type_album() {
	$album_slug = function_exists( 'ot_get_option' ) ? sanitize_title( ot_get_option( 'album_slug', 'album' ) ) : 'album';
	$labels     = array(
		'name'          => esc_html__( 'Albums', 'twofold' ),
		'singular_name' => esc_html__( 'Album', 'twofold' ),
		'rewrite'       => array( 'slug' => esc_html__( 'album', 'twofold' ) ),
		'add_new'       => _x( 'Add New Album', 'album', 'twofold' ),
		'add_new_item'  => esc_html__( 'Add New Album', 'twofold' ),
		'edit_item'     => esc_html__( 'Edit Album', 'twofold' ),
		'new_item'      => esc_html__( 'New Album', 'twofold' ),
		'view_item'     => esc_html__( 'View Album', 'twofold' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'query_var'           => true,
		'rewrite'             => array(
			'slug'       => $album_slug,
			'with_front' => false,
		),
		'show_in_rest'        => true,
		'has_archive'         => false,
		'menu_icon'           => 'dashicons-schedule',
		'capability_type'     => 'post',
		'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' ),
	);

	register_post_type( 'album', $args );
	flush_rewrite_rules();

	$category_labels = array(
		'name'          => esc_html__( 'Categories', 'twofold' ),
		'singular_name' => esc_html__( 'Category', 'twofold' ),
		'search_items'  => esc_html__( 'Search Categories', 'twofold' ),
		'all_items'     => esc_html__( 'All Categories', 'twofold' ),
		'edit_item'     => esc_html__( 'Edit Category', 'twofold' ),
		'update_item'   => esc_html__( 'Update Category', 'twofold' ),
		'add_new_item'  => esc_html__( 'Add New Category', 'twofold' ),
		'menu_name'     => esc_html__( 'Album Categories', 'twofold' ),
	);

	register_taxonomy(
		'album-category',
		array( 'album' ),
		array(
			'hierarchical' => true,
			'labels'       => $category_labels,
			'show_ui'      => true,
			'query_var'    => true,
		)
	);
}

/* Gallery */
function thb_post_type_gallery() {
	$gallery_slug = function_exists( 'ot_get_option' ) ? sanitize_title( ot_get_option( 'gallery_slug', 'gallery' ) ) : 'gallery';
	$labels       = array(
		'name'          => esc_html__( 'Galleries', 'twofold' ),
		'singular_name' => esc_html__( 'Gallery', 'twofold' ),
		'rewrite'       => array( 'slug' => esc_html__( 'gallery', 'twofold' ) ),
		'add_new'       => _x( 'Add New Gallery', 'gallery', 'twofold' ),
		'add_new_item'  => esc_html__( 'Add New Gallery', 'twofold' ),
		'edit_item'     => esc_html__( 'Edit Gallery', 'twofold' ),
		'new_item'      => esc_html__( 'New Gallery', 'twofold' ),
		'view_item'     => esc_html__( 'View Gallery', 'twofold' ),
	);

	$args = array(
		'labels'              => $labels,
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'query_var'           => true,
		'rewrite'             => array(
			'slug'       => $gallery_slug,
			'with_front' => false,
		),
		'show_in_rest'        => true,
		'menu_icon'           => 'dashicons-images-alt',
		'capability_type'     => 'post',
		'supports'            => array( 'title', 'comments' ),
	);

	register_post_type( 'gallery', $args );
	flush_rewrite_rules();
}

/* Collections */
function thb_post_type_collection() {
	$collection_slug = function_exists( 'ot_get_option' ) ? sanitize_title( ot_get_option( 'collection_slug', 'collection' ) ) : 'collection';
	$labels          = array(
		'name'          => esc_html__( 'Collections', 'twofold' ),
		'singular_name' => esc_html__( 'Collection', 'twofold' ),
		'rewrite'       => array( 'slug' => esc_html__( 'collection', 'twofold' ) ),
		'add_new'       => _x( 'Add New Collection', 'collection', 'twofold' ),
		'add_new_item'  => esc_html__( 'Add New Collection', 'twofold' ),
		'edit_item'     => esc_html__( 'Edit Collection', 'twofold' ),
		'new_item'      => esc_html__( 'New Collection', 'twofold' ),
		'view_item'     => esc_html__( 'View Collection', 'twofold' ),
	);

	$args = array(
		'labels'              => $labels,
		'description'         => esc_html__( 'Collections are groups of albums', 'twofold' ),
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'query_var'           => true,
		'rewrite'             => array(
			'slug'       => $collection_slug,
			'with_front' => false,
		),
		'show_in_rest'        => true,
		'hierarchical'        => true,
		'menu_icon'           => 'dashicons-exerpt-view',
		'capability_type'     => 'page',
		'supports'            => array( 'title' ),
	);

	register_post_type( 'collection', $args );
	flush_rewrite_rules();
}
/* Initialize post types */
add_action( 'init', 'thb_post_type_gallery' );
add_action( 'init', 'thb_post_type_album' );
add_action( 'init', 'thb_post_type_collection' );
